<?php
declare(strict_types=1);
/**
 * Plugin Name: Booking System Pro
 * Description: Modular booking system (Core + Commerce, Planner, Sales, Intelligence).
 * Version: 1.0.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/core/bootstrap.php';
