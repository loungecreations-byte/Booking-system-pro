<?php
declare(strict_types=1);

namespace BSP\Intelligence;

use BSP\Core\CoreServiceProvider;
use BSP\Core\Interfaces\ModuleInterface;
use BSP\Intelligence\Rest\Controller as RestController;

/**
 * Intelligence module delivering trend, anomaly, and recommendation tools.
 */
final class Module implements ModuleInterface
{
    /**
     * Register REST routes and log module initialisation.
     */
    public function init(): void
    {
        CoreServiceProvider::logger()->log('Intelligence module initialized');

        if (\function_exists('add_action')) {
            \add_action('rest_api_init', [RestController::class, 'register']);
        }
    }

    /**
     * Return the top-k entries sorted by descending value.
     *
     * @param array<string, float|int> $kv
     *
     * @return array<string, float|int>
     */
    public function analyzeTrends(array $kv, int $k = 3): array
    {
        \arsort($kv);

        return \array_slice($kv, 0, $k, true);
    }

    /**
     * Detect series entries that exceed the threshold.
     *
     * @param array<string, float|int> $series
     *
     * @return array<string, float>
     */
    public function detectAnomalies(array $series, float $threshold): array
    {
        $anomalies = [];

        foreach ($series as $key => $value) {
            $numericValue = (float)$value;

            if ($numericValue >= $threshold) {
                $anomalies[(string)$key] = $numericValue;
            }
        }

        return $anomalies;
    }

    /**
     * Produce moving-average forecasts over the provided window.
     *
     * @param array<string, float|int> $series
     *
     * @return array<string, float>
     */
    public function forecastDemand(array $series, int $window = 3): array
    {
        $keys = \array_keys($series);
        $values = \array_values($series);
        $count = \count($values);
        $forecasts = [];

        for ($index = 0; $index < $count; $index++) {
            $start = \max(0, $index - $window + 1);
            $slice = \array_slice($values, $start, $index - $start + 1);
            $average = empty($slice) ? 0.0 : (\array_sum($slice) / \count($slice));
            $forecasts[(string)$keys[$index]] = \round((float)$average, 2);
        }

        return $forecasts;
    }

    /**
     * Suggest upsell SKUs based on catalog relationships.
     *
     * @param array<int, array<string, mixed>> $cart
     * @param array<int, array<string, mixed>> $catalog
     *
     * @return array<int, string>
     */
    public function recommendUpsell(array $cart, array $catalog): array
    {
        $inCart = [];
        foreach ($cart as $line) {
            $sku = (string)($line['sku'] ?? '');
            if ('' !== $sku) {
                $inCart[$sku] = true;
            }
        }

        $suggested = [];
        foreach ($catalog as $item) {
            $related = $item['related'] ?? [];
            if (!\is_array($related)) {
                continue;
            }

            foreach ($related as $sku) {
                $candidate = (string)$sku;
                if ('' === $candidate || isset($inCart[$candidate])) {
                    continue;
                }

                $suggested[$candidate] = true;
            }
        }

        return \array_keys($suggested);
    }

    /**
     * Compute KPI values such as revenue and average order value.
     *
     * @param array<string, float|int> $metrics
     *
     * @return array<string, float|int>
     */
    public function computeKPIs(array $metrics): array
    {
        $orders = (int)($metrics['orders'] ?? 0);
        $revenue = (float)($metrics['revenue'] ?? 0.0);
        $averageOrderValue = $orders > 0 ? $revenue / $orders : 0.0;

        return [
            'orders' => $orders,
            'revenue' => \round($revenue, 2),
            'aov' => \round($averageOrderValue, 2),
        ];
    }

    /**
     * Segment customers by total spend into VIP, REGULAR, and NEW buckets.
     *
     * @param array<int, array<string, mixed>> $customers
     *
     * @return array<string, array<int, string>>
     */
    public function segmentCustomers(array $customers): array
    {
        $segments = [
            'VIP' => [],
            'REGULAR' => [],
            'NEW' => [],
        ];

        foreach ($customers as $customer) {
            $identifier = (string)($customer['id'] ?? '');
            $total = (float)($customer['total'] ?? 0.0);

            if ('' === $identifier) {
                continue;
            }

            if ($total >= 1000.0) {
                $segments['VIP'][] = $identifier;
                continue;
            }

            if ($total >= 100.0) {
                $segments['REGULAR'][] = $identifier;
                continue;
            }

            $segments['NEW'][] = $identifier;
        }

        return $segments;
    }
}
