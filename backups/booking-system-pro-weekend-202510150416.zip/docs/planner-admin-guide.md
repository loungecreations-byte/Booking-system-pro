# Planner Admin Guide

## Overzicht
Deze gids ondersteunt admins bij het beheren van de planner-module in het WordPress-dashboard. Gebruik dit document naast de releasechecklist en regressietests.

## Voorwaarden
- WordPress + WooCommerce geactiveerd
- Boekbare producttype `bookable_service` beschikbaar
- Plannerpagina met shortcode `[sbdp_dayplanner]`

## Boekbare Activiteit Aanmaken
1. Ga naar `Producten > Nieuwe toevoegen`.
2. Kies producttype **Boekbare activiteit**.
3. Vul prijs, duur (`_sbdp_duration`) en resource (_boekingresource_) in.
4. Publiceer. Controleer dat het product in de planner REST (`GET /sbdp/v1/services`) verschijnt.

## Beschikbaarheidsregels Bewerken
1. Navigeer naar **Bookings > Availability**.
2. Gebruik de kalender om blokken toe te voegen (drag & drop) en klik op **Publiceer**.
3. Controleer via planner-UI of de wijzigingen actief zijn (planner geeft conflictmelding bij gesloten blok).

## Plannerpagina & Front-end
1. Plaats shortcode `[sbdp_dayplanner]` op de gewenste pagina of Elementor-widget.
2. De Planner-config (`SBDP_CFG`) levert REST endpoints + nonce.
3. Planner-UI: selecteer datum, sleep activiteiten, valideer totale prijs, test �Boek & betaal� (redirect) en �Doe aanvraag� (succesmelding).

## Snelle Acties (Dashboard)
Het dashboard toont:
- Aantal boekbare activiteiten
- Aantal resources
- Boekingen vandaag (status breakdown)
- Knoppen naar nieuwe activiteit, resourcebeheer, beschikbaarheidsregels

## REST & Beveiliging
- Client requests vereisen `X-SBDP-Nonce` (verkregen via planner). Zonder nonce ? HTTP 403.
- Filters beschikbaar:
  - `sbdp_rest_rate_limit( bool|WP_Error, WP_REST_Request $request, string $bucket )`
  - `sbdp/public_rest/allow_request( null|bool|WP_Error, $request, $bucket )`
  - `sbdp/public_rest/validate_nonce( null|bool|WP_Error, $nonce, $request, $bucket )`

## Regressie Tests (Samenvatting)
- Planner drag & drop: activiteit toevoegen/verwijderen.
- Compose pay & request: check redirect + melding.
- Pricing preview bij resource met beperkte capaciteiten.
- REST smoke (`scripts/rest-smoke.ps1`) met `-QuoteProductId`.

## Automatisering (Aanbevolen)
- Playwright/Cypress tests voor planner UI (drag, compose, share).
- Integreer E2E runs in GitHub Actions (optioneel aparte workflow).
