<?php

declare(strict_types=1);

namespace BSP\Tests\Unit\Funnels;

use PHPUnit\Framework\TestCase;

final class FunnelServiceTest extends TestCase {

	public function testPlaceholder(): void {
		$this->assertTrue( true, 'Funnel service tests pending implementation.' );
	}
}
