<?php

namespace {
	if ( false ) {
		class WP_REST_Controller {
			protected string $namespace;

			protected string $rest_base;

			public function get_items( \WP_REST_Request $request ) {}

			public function create_item( \WP_REST_Request $request ) {}
		}
	}
}

