<?php

/**
 * Planning admin dashboard.
 *
 * @package Booking_Planning
 */

namespace Booking_Planning\Admin;

final class Dashboard {

	/**
	 * Register hooks.
	 */
	public static function register(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
	}

	/**
	 * Add planning submenu under Booking System Pro core menu (if present).
	 */
	public static function register_menu(): void {
		add_submenu_page(
			'sbdp_bookings',
			__( 'Planning Matrix', 'booking-planning' ),
			__( 'Planning Matrix', 'booking-planning' ),
			'manage_options',
			'booking-planning-matrix',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue admin assets via booking-core hook or direct load.
	 *
	 * @param string $hook Current admin screen.
	 */
	public static function enqueue_assets( string $hook ): void {
		if ( 'bookings_page_booking-planning-matrix' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'booking-planning/admin',
			BOOKING_PLANNING_URL . 'assets/css/admin-planning.css',
			array(),
			BOOKING_PLANNING_VERSION
		);

		wp_enqueue_script(
			'booking-planning/admin',
			BOOKING_PLANNING_URL . 'assets/js/admin-planning.js',
			array( 'wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n' ),
			BOOKING_PLANNING_VERSION,
			true
		);

		wp_localize_script(
			'booking-planning/admin',
			'BookingPlanningConfig',
			array(
				'rest' => array(
					'base'  => esc_url_raw( rest_url( 'sbdp-planning/v1' ) ),
					'nonce' => wp_create_nonce( 'wp_rest' ),
				),
			)
		);
	}

	/**
	 * Render admin page container.
	 */
	public static function render_page(): void {
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Planning Matrix', 'booking-planning' ); ?></h1>
			<div id="booking-planning-app" class="booking-planning-app" data-component="planning-matrix"></div>
		</div>
		<?php
	}
}
