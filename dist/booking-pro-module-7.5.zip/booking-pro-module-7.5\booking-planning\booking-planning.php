<?php

/**
 * Plugin Name: Booking System Pro - Planning Module
 * Description: Adds planning dashboards, resource assignments, and scheduling tools for Booking System Pro.
 * Version:     1.0.0
 * Author:      Own Creations
 * Text Domain: booking-planning
 * License:     GPL v2 or later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'BOOKING_PLANNING_FILE' ) ) {
	return;
}

define( 'BOOKING_PLANNING_FILE', __FILE__ );

define( 'BOOKING_PLANNING_PATH', plugin_dir_path( BOOKING_PLANNING_FILE ) );

define( 'BOOKING_PLANNING_URL', plugin_dir_url( BOOKING_PLANNING_FILE ) );

define( 'BOOKING_PLANNING_VERSION', '1.0.0' );

define( 'BOOKING_PLANNING_MIN_CORE', '2.0.0' );

define( 'BOOKING_PLANNING_MIN_WP', '6.0' );

require_once BOOKING_PLANNING_PATH . 'includes/class-autoloader.php';

Booking_Planning\Autoloader::register();

Booking_Planning\Plugin::init();
