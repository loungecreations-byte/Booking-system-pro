(function(){
	if (!window.BookingPlanningConfig || !window.wp || !window.wp.element || !window.wp.apiFetch) {
		return;
	}

	const { createElement: h, useState, useEffect } = window.wp.element;
	const { __ } = window.wp.i18n || { __: ( s ) => s };
	const apiFetch = window.wp.apiFetch;

	const mountComponent = (element, target) => {
		if (typeof window.wp.element.render === 'function') {
			window.wp.element.render(element, target);
			return;
		}

		if (window.wp.element.createRoot) {
			const root = window.wp.element.createRoot(target);
			root.render(element);
		}
	};

	const formatDateLabel = (iso) => {
		try {
			return new Date(iso).toLocaleDateString();
		} catch (e) {
			return iso;
		}
	};

	const getToday = () => {
		const today = new Date();
		const month = String(today.getMonth() + 1).padStart(2, '0');
		const day = String(today.getDate()).padStart(2, '0');
		return `${today.getFullYear()}-${month}-${day}`;
	};

	const initialState = {
		loading: true,
		error: null,
		data: null,
		from: getToday(),
	};

	function PlanningMatrixApp(){
		const [state, setState] = useState(initialState);

		const loadMatrix = (from) => {
			const queryFrom = from || getToday();
			setState((prev) => ({ ...prev, loading: true, error: null, from: queryFrom }));

			apiFetch({
				path: `${BookingPlanningConfig.rest.base.replace(/\/$/, '')}/matrix?from=${encodeURIComponent(queryFrom)}`,
				method: 'GET',
				headers: {
					'X-WP-Nonce': BookingPlanningConfig.rest.nonce,
				},
			})
				.then((response) => {
					setState((prev) => ({ ...prev, loading: false, data: response, error: null }));
				})
				.catch((error) => {
					const message = error && error.message ? error.message : __('Er trad een fout op tijdens het laden van de planning.', 'booking-planning');
					setState((prev) => ({ ...prev, loading: false, error: message }));
				});
		};

		useEffect(() => {
			loadMatrix(state.from);
			// eslint-disable-next-line react-hooks/exhaustive-deps
		}, []);

		const handleDateChange = (event) => {
			loadMatrix(event.target.value);
		};

		const data = state.data || { context: { days: [], resources: [] }, assignments: [] };
		const days = Array.isArray(data.context?.days) ? data.context.days : [];
		const resources = Array.isArray(data.context?.resources) ? data.context.resources : [];
		const assignments = Array.isArray(data.assignments) ? data.assignments : [];

		const assignmentsByResource = assignments.reduce((acc, assignment) => {
			const key = assignment.resource_id || 0;
			if (!acc[key]) {
				acc[key] = [];
			}
			acc[key].push(assignment);
			return acc;
		}, {});

		const renderCell = (resourceId, day) => {
			const items = (assignmentsByResource[resourceId] || []).filter((assignment) => {
				if (!assignment.period || !assignment.period.from) {
					return false;
				}
				const startDate = assignment.period.from.substring(0, 10);
				return startDate === day.date;
			});

			if (!items.length) {
				return h('div', { className: 'booking-planning-cell booking-planning-cell--empty' }, __('Geen boekingen', 'booking-planning'));
			}

			return h(
				'div',
				{ className: 'booking-planning-cell booking-planning-cell--filled' },
				items.map((item) => {
					const startLabel = item.period?.from ? item.period.from.substring(11, 16) : '';
					const endLabel = item.period?.to ? item.period.to.substring(11, 16) : '';
					const booking = item.booking || {};
					const colorStyle = { borderLeft: `4px solid ${booking.color || '#0ea5e9'}` };

					const hasTotal = typeof booking.total !== 'undefined' && booking.total !== null;
					const totalLabel = hasTotal ? Number(booking.total).toFixed(2) : null;

					return h(
						'div',
						{ key: item.id || `${resourceId}-${day.date}`, className: 'booking-planning-assignment', style: colorStyle },
						h('strong', null, booking.id ? `#${booking.id}` : __('Boeking', 'booking-planning')),
						h('div', { className: 'booking-planning-assignment__time' }, `${startLabel} - ${endLabel}`),
						hasTotal ? h('div', { className: 'booking-planning-assignment__total' }, `${booking.currency || 'EUR'} ${totalLabel}`) : null,
						booking.status ? h('span', { className: 'booking-planning-assignment__status' }, booking.status) : null
					);
				})
			);
		};

		return h(
			'div',
			{ className: 'booking-planning-container' },
			h('div', { className: 'booking-planning-toolbar' },
				h('label', { className: 'booking-planning-toolbar__label', htmlFor: 'booking-planning-from' }, __('Vanaf datum', 'booking-planning')),
				h('input', {
					id: 'booking-planning-from',
					className: 'booking-planning-toolbar__input',
					type: 'date',
					value: state.from,
					onChange: handleDateChange,
				}),
				state.loading ? h('span', { className: 'booking-planning-toolbar__loading' }, __('Laden...', 'booking-planning')) : null,
				state.error ? h('span', { className: 'booking-planning-toolbar__error' }, state.error) : null
			),
			renderMatrixTable(days, resources)
		);

		function renderMatrixTable(daysList, resourcesList) {
			if (state.loading) {
				return h('div', { className: 'booking-planning-placeholder' }, __('Planner wordt geladen...', 'booking-planning'));
			}

			if (!resourcesList.length) {
				return h('div', { className: 'booking-planning-empty' }, __('Er zijn nog geen resources beschikbaar voor deze periode.', 'booking-planning'));
			}

			return h(
				'table',
				{ className: 'booking-planning-matrix wp-list-table widefat fixed striped' },
				h('thead', null,
					h('tr', null,
						h('th', { className: 'column-resource' }, __('Resource', 'booking-planning')),
						...daysList.map((day) => h('th', { key: day.date }, day.label || formatDateLabel(day.date)))
					)
				),
				h('tbody', null,
					resourcesList.map((resource) => h(
						'tr',
						{ key: resource.id },
						h('td', { className: 'column-resource' },
							h('strong', null, resource.title || __('Naamloos', 'booking-planning')),
							resource.capacity ? h('div', { className: 'booking-planning-resource__capacity' }, `${__('Capaciteit', 'booking-planning')}: ${resource.capacity}`) : null
						),
						...daysList.map((day) => h('td', { key: `${resource.id}-${day.date}` }, renderCell(resource.id, day)))
					))
				)
			);
		}
	}

	const target = document.getElementById('booking-planning-app');
	if (target && !target.dataset.initialized) {
		target.dataset.initialized = '1';
		mountComponent(h(PlanningMatrixApp), target);
	}
})();
