# Vendor Management Backend

## REST API
- `GET /wp-json/bsp/v1/vendors` - list vendors; supports `status`, `search`, pagination, and `with_products=true` to include product ids.
- `POST /wp-json/bsp/v1/vendors` - create vendor records; accepts core profile fields plus optional `product_ids` to assign products immediately.
- `GET /wp-json/bsp/v1/vendors/{id}` - fetch a single vendor; add `with_products=true` to embed assignments.
- `PATCH /wp-json/bsp/v1/vendors/{id}` - update vendor details and optional `product_ids`.
- `POST /wp-json/bsp/v1/vendors/{id}/status` - move vendor between `pending`, `active`, `suspended`, or `archived`.
- `POST /wp-json/bsp/v1/vendors/{id}/products` - replace product assignments in one request.

All routes require the `manage_bsp_sales` capability and return `vendor` payloads backed by `BSP\Sales\Vendors\VendorService`.

## Admin Surface
- New submenu: **Sales Suite -> Vendors** renders the shared React shell (`data-screen="vendors"`).
- The screen lists vendors, allows inline status changes, and provides a form for creating or editing vendors plus optional product assignments.
- Script localisation continues to expose the `bsp/v1` REST base; the vendor desk reuses `assets/js/bsp-sales-admin.js`.

## Data Model
- Vendors persist to `{$wpdb->prefix}bsp_vendors` with JSON-capable columns for `channels`, `capabilities`, and `metadata`.
- Product relationships live in `{$wpdb->prefix}bsp_products.vendor_id`; use `VendorService::syncProducts()` to keep assignments consistent.
- Installer seeds two starter vendors (`direct-outlet`, `marketplace-syndicate`) for immediate smoke testing.

## Service Helpers
- `VendorService::list()` and `VendorService::get()` allow optional inclusion of product ids.
- `VendorService::syncProducts()` wraps repository upserts and returns attached/detached ids for audit logging.
- Input sanitisation is handled by `VendorValidator`; reuse it when extending CLI or job integrations.
