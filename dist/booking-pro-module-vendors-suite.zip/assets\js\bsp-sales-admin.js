(function () {
    const globals = window || {};
    const wp = globals.wp || {};
    const rootEl = document.getElementById('bsp-sales-admin-root');
    const wrapEl = document.querySelector('.bsp-sales-wrap');

    if (!rootEl || !wrapEl) {
        return;
    }

    if (!wp.element || typeof wp.element.createElement !== 'function') {
        if ((wrapEl.getAttribute('data-screen') || '') === 'vendors') {
            console.warn('BSP Sales admin requires wp.element for the vendors screen.');
        }
        return;
    }

    const screen = wrapEl.getAttribute('data-screen') || '';
    const config = globals.BSP_SALES_ADMIN || {};
    const {
        createElement: h,
        useEffect,
        useState,
        Fragment,
        createRoot,
        render,
    } = wp.element;
    const __ = wp.i18n && typeof wp.i18n.__ === 'function' ? wp.i18n.__ : (text) => text;

    if (screen !== 'vendors') {
        console.info('BSP Sales admin UI booted');
        return;
    }

    const vendorStatuses = Array.isArray(config.vendorStatuses) && config.vendorStatuses.length
        ? config.vendorStatuses
        : ['pending', 'active', 'suspended', 'archived'];
    const canMutate = !!(config.capabilities && config.capabilities.manageVendors);
    const restBase = (config.restBase || '').replace(/\/$/, '');

    const buildUrl = (path) => {
        const trimmed = String(path || '').replace(/^\/+/, '');
        return restBase ? restBase + '/' + trimmed : trimmed;
    };

    const apiRequest = async (path, options = {}) => {
        const opts = Object.assign({}, options);
        opts.headers = Object.assign({}, opts.headers || {});
        if (config.nonce && !opts.headers['X-WP-Nonce']) {
            opts.headers['X-WP-Nonce'] = config.nonce;
        }
        if (opts.body && !opts.headers['Content-Type']) {
            opts.headers['Content-Type'] = 'application/json';
        }

        const response = await fetch(buildUrl(path), opts);
        let data = null;
        try {
            data = await response.json();
        } catch (error) {
            data = null;
        }

        if (!response.ok) {
            const message = data && data.message ? data.message : response.statusText || __('Request failed', 'sbdp');
            const error = new Error(message);
            error.data = data;
            throw error;
        }

        return data;
    };

    const parseCommaList = (value) => String(value || '')
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean);

    const parseIds = (value) => parseCommaList(value)
        .map((item) => parseInt(item, 10))
        .filter((item) => Number.isInteger(item) && item > 0);

    const VendorsApp = () => {
        const [vendors, setVendors] = useState([]);
        const [loading, setLoading] = useState(true);
        const [error, setError] = useState('');
        const [notice, setNotice] = useState('');
        const [saving, setSaving] = useState(false);
        const [editingId, setEditingId] = useState(null);
        const [busyId, setBusyId] = useState(null);
        const [form, setForm] = useState({
            name: '',
            slug: '',
            status: vendorStatuses[0] || 'pending',
            channels: '',
            commission: '',
            products: '',
            contactName: '',
            contactEmail: '',
            webhookUrl: '',
        });

        const resetForm = () => {
            setEditingId(null);
            setForm({
                name: '',
                slug: '',
                status: vendorStatuses[0] || 'pending',
                channels: '',
                commission: '',
                products: '',
                contactName: '',
                contactEmail: '',
                webhookUrl: '',
            });
        };

        const loadVendors = async () => {
            setLoading(true);
            setError('');
            try {
                const result = await apiRequest('vendors?per_page=100&with_products=1', { method: 'GET' });
                setVendors(Array.isArray(result && result.vendors) ? result.vendors : []);
            } catch (err) {
                setError(err && err.message ? err.message : __('Unable to load vendors.', 'sbdp'));
            } finally {
                setLoading(false);
            }
        };

        useEffect(() => {
            loadVendors();
        }, []);

        const handleEdit = (vendor) => {
            setEditingId(vendor.id);
            setForm({
                name: vendor.name || '',
                slug: vendor.slug || '',
                status: vendor.status || vendorStatuses[0] || 'pending',
                channels: Array.isArray(vendor.channels) ? vendor.channels.join(', ') : '',
                commission: vendor.commission_rate != null ? String(vendor.commission_rate) : '',
                products: Array.isArray(vendor.product_ids) ? vendor.product_ids.join(', ') : '',
                contactName: vendor.contact_name || '',
                contactEmail: vendor.contact_email || '',
                webhookUrl: vendor.webhook_url || '',
            });
            setNotice('');
        };

        const updateForm = (field) => (event) => {
            setForm((current) => Object.assign({}, current, { [field]: event.target.value }));
        };

        const submitForm = async (event) => {
            event.preventDefault();
            if (!canMutate || saving) {
                return;
            }

            setSaving(true);
            setError('');
            setNotice('');

            const payload = {
                name: form.name,
                slug: form.slug || undefined,
                status: form.status,
                channels: parseCommaList(form.channels),
                commission_rate: form.commission === '' ? null : parseFloat(form.commission),
                contact_name: form.contactName || null,
                contact_email: form.contactEmail || null,
                webhook_url: form.webhookUrl || null,
            };

            const productIds = parseIds(form.products);
            if (productIds.length) {
                payload.product_ids = productIds;
            }

            try {
                const path = editingId ? `vendors/${editingId}` : 'vendors';
                const method = editingId ? 'PATCH' : 'POST';
                const response = await apiRequest(path, {
                    method,
                    body: JSON.stringify(payload),
                });

                const vendor = response && response.vendor ? response.vendor : null;
                if (vendor) {
                    setVendors((current) => {
                        const filtered = current.filter((item) => item.id !== vendor.id);
                        return [vendor].concat(filtered).sort((a, b) => (a.name || '').localeCompare(b.name || ''));
                    });
                } else {
                    await loadVendors();
                }

                setNotice(editingId ? __('Vendor updated.', 'sbdp') : __('Vendor created.', 'sbdp'));
                resetForm();
            } catch (err) {
                setError(err && err.message ? err.message : __('Unable to save vendor.', 'sbdp'));
            } finally {
                setSaving(false);
            }
        };

        const changeStatus = async (vendor, nextStatus) => {
            if (!canMutate || !nextStatus) {
                return;
            }
            setBusyId(vendor.id);
            setError('');
            setNotice('');
            try {
                const response = await apiRequest(`vendors/${vendor.id}/status`, {
                    method: 'POST',
                    body: JSON.stringify({ status: nextStatus }),
                });
                const updated = response && response.vendor ? response.vendor : null;
                setVendors((current) => current.map((item) => (item.id === vendor.id ? (updated || Object.assign({}, item, { status: nextStatus })) : item)));
                setNotice(__('Status updated.', 'sbdp'));
            } catch (err) {
                setError(err && err.message ? err.message : __('Unable to update status.', 'sbdp'));
            } finally {
                setBusyId(null);
            }
        };

        const syncProducts = async (vendor) => {
            if (!canMutate) {
                return;
            }
            setBusyId(vendor.id);
            setError('');
            setNotice('');
            const productIds = Array.isArray(vendor.product_ids) ? vendor.product_ids : [];
            try {
                const response = await apiRequest(`vendors/${vendor.id}/products`, {
                    method: 'POST',
                    body: JSON.stringify({ product_ids: productIds }),
                });
                if (response && response.vendor) {
                    setVendors((current) => current.map((item) => (item.id === vendor.id ? response.vendor : item)));
                }
                setNotice(__('Assignments refreshed.', 'sbdp'));
            } catch (err) {
                setError(err && err.message ? err.message : __('Unable to sync products.', 'sbdp'));
            } finally {
                setBusyId(null);
            }
        };

        const vendorRows = () => {
            if (loading) {
                return h('tr', { key: 'loading' }, [
                    h('td', { colSpan: 6 }, __('Loading vendors?', 'sbdp')),
                ]);
            }

            if (!vendors.length) {
                return h('tr', { key: 'empty' }, [
                    h('td', { colSpan: 6 }, __('No vendors configured yet.', 'sbdp')),
                ]);
            }

            return vendors.map((vendor) => {
                const channelLabel = Array.isArray(vendor.channels) && vendor.channels.length
                    ? vendor.channels.join(', ')
                    : __('Not set', 'sbdp');
                const productCount = Array.isArray(vendor.product_ids) ? vendor.product_ids.length : 0;

                return h('tr', { key: vendor.id }, [
                    h('td', { className: 'column-primary' }, [
                        h('strong', {}, vendor.name || __('(untitled)', 'sbdp')),
                        canMutate && h('div', { className: 'row-actions' }, [
                            h('button', {
                                type: 'button',
                                className: 'button-link',
                                onClick: () => handleEdit(vendor),
                            }, __('Edit', 'sbdp')),
                        ]),
                    ].filter(Boolean)),
                    h('td', {}, vendor.slug || '?'),
                    h('td', {}, canMutate
                        ? h('select', {
                            value: vendor.status,
                            onChange: (event) => changeStatus(vendor, event.target.value),
                            disabled: busyId === vendor.id,
                        }, vendorStatuses.map((status) => h('option', { key: status, value: status }, status)))
                        : (vendor.status || '?')),
                    h('td', {}, channelLabel),
                    h('td', {}, String(productCount)),
                    h('td', {}, canMutate && productCount > 0 ? h('button', {
                        type: 'button',
                        className: 'button button-secondary',
                        disabled: busyId === vendor.id,
                        onClick: () => syncProducts(vendor),
                    }, busyId === vendor.id ? __('Syncing?', 'sbdp') : __('Refresh', 'sbdp')) : '?'),
                ]);
            });
        };

        return h(Fragment, {}, [
            h('div', { className: 'bsp-admin-messages' }, [
                error && h('div', { className: 'notice notice-error' }, h('p', {}, error)),
                notice && h('div', { className: 'notice notice-success' }, h('p', {}, notice)),
            ].filter(Boolean)),
            h('div', { className: 'bsp-vendors-grid' }, [
                h('div', { className: 'bsp-vendors-list' }, [
                    h('div', { className: 'bsp-vendors-list-header' }, [
                        h('h2', {}, __('Vendors', 'sbdp')),
                        h('button', {
                            type: 'button',
                            className: 'button',
                            onClick: loadVendors,
                            disabled: loading,
                        }, loading ? __('Refreshing?', 'sbdp') : __('Refresh', 'sbdp')),
                    ]),
                    h('table', { className: 'widefat striped' }, [
                        h('thead', {}, h('tr', {}, [
                            h('th', { className: 'column-primary' }, __('Name', 'sbdp')),
                            h('th', {}, __('Slug', 'sbdp')),
                            h('th', {}, __('Status', 'sbdp')),
                            h('th', {}, __('Channels', 'sbdp')),
                            h('th', {}, __('Products', 'sbdp')),
                            h('th', {}, __('Actions', 'sbdp')),
                        ])),
                        h('tbody', {}, vendorRows()),
                    ]),
                ]),
                canMutate && h('div', { className: 'bsp-vendors-form' }, [
                    h('h2', {}, editingId ? __('Edit Vendor', 'sbdp') : __('Create Vendor', 'sbdp')),
                    h('form', { onSubmit: submitForm }, [
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-name' }, __('Name', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-name',
                                type: 'text',
                                required: true,
                                value: form.name,
                                onChange: updateForm('name'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-slug' }, __('Slug', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-slug',
                                type: 'text',
                                value: form.slug,
                                onChange: updateForm('slug'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-status' }, __('Status', 'sbdp')),
                            h('select', {
                                id: 'bsp-vendor-status',
                                value: form.status,
                                onChange: updateForm('status'),
                                disabled: saving,
                            }, vendorStatuses.map((status) => h('option', { key: status, value: status }, status))),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-channels' }, __('Channels (comma separated)', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-channels',
                                type: 'text',
                                value: form.channels,
                                onChange: updateForm('channels'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-products' }, __('Product IDs (comma separated)', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-products',
                                type: 'text',
                                value: form.products,
                                onChange: updateForm('products'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-commission' }, __('Commission Rate (%)', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-commission',
                                type: 'number',
                                step: '0.01',
                                min: '0',
                                max: '100',
                                value: form.commission,
                                onChange: updateForm('commission'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-contact-name' }, __('Contact Name', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-contact-name',
                                type: 'text',
                                value: form.contactName,
                                onChange: updateForm('contactName'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-contact-email' }, __('Contact Email', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-contact-email',
                                type: 'email',
                                value: form.contactEmail,
                                onChange: updateForm('contactEmail'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', {}, [
                            h('label', { htmlFor: 'bsp-vendor-webhook' }, __('Webhook URL', 'sbdp')),
                            h('input', {
                                id: 'bsp-vendor-webhook',
                                type: 'url',
                                value: form.webhookUrl,
                                onChange: updateForm('webhookUrl'),
                                disabled: saving,
                            }),
                        ]),
                        h('p', { className: 'submit' }, [
                            h('button', {
                                type: 'submit',
                                className: 'button button-primary',
                                disabled: saving,
                            }, saving ? __('Saving?', 'sbdp') : editingId ? __('Update Vendor', 'sbdp') : __('Create Vendor', 'sbdp')),
                            editingId && h('button', {
                                type: 'button',
                                className: 'button button-secondary',
                                onClick: resetForm,
                                disabled: saving,
                                style: { marginLeft: '0.5rem' },
                            }, __('Cancel', 'sbdp')),
                        ].filter(Boolean)),
                    ]),
                ]),
            ].filter(Boolean)),
        ]);
    };

    const rootFactory = typeof createRoot === 'function' ? createRoot : null;
    if (rootFactory) {
        rootFactory(rootEl).render(h(VendorsApp));
    } else if (typeof render === 'function') {
        render(h(VendorsApp), rootEl);
    }
})();
