// architecture.md placeholder
