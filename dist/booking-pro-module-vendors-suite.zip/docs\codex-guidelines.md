// codex-guidelines.md placeholder
