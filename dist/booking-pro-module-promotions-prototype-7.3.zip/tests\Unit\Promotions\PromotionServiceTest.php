<?php

declare(strict_types=1);

namespace BSP\Tests\Unit\Promotions;

use PHPUnit\Framework\TestCase;

final class PromotionServiceTest extends TestCase
{
    public function testPlaceholder(): void
    {
        $this->assertTrue(true, 'Promotion service tests pending implementation.');
    }
}
