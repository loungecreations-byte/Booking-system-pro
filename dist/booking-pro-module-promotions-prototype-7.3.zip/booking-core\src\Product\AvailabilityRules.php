<?php

declare(strict_types=1);

namespace BSPModule\Core\Product;

final class AvailabilityRules
{
    public static function defaultRules(): array
    {
        return [
            'default'          => 'open',
            'exclude_weekdays' => [],
            'exclude_months'   => [],
            'exclude_times'    => [],
            'overrides'        => [],
        ];
    }
}