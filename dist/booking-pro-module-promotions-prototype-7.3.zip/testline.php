﻿return \Foo\Bar;
