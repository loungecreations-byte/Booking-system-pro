<?php
/**
 * Builds planning matrix payloads.
 *
 * @package Booking_Planning
 */

namespace Booking_Planning\Services;

use Booking_Core\Database\Repository\Bookings_Repository;
use Booking_Core\Database\Repository\Resources_Repository;
use Booking_Core\Database\Repository\Assignments_Repository;
use DateInterval;
use DatePeriod;
use DateTimeImmutable;
use wpdb;

final class Matrix_Builder {
	private Bookings_Repository $bookings;

	private Resources_Repository $resources;

	private Assignments_Repository $assignments;

	public function __construct( wpdb $wpdb ) {
		$this->bookings    = new Bookings_Repository( $wpdb );
		$this->resources   = new Resources_Repository( $wpdb );
		$this->assignments = new Assignments_Repository( $wpdb );
	}

	/**
	 * Build matrix payload between two dates (Y-m-d).
	 */
	public function build( string $from, string $to ): array {
		$from_dt = new DateTimeImmutable( $from . ' 00:00:00', wp_timezone() );
		$to_dt   = new DateTimeImmutable( $to . ' 23:59:59', wp_timezone() );

		$days = [];
		$period = new DatePeriod( $from_dt, new DateInterval( 'P1D' ), $to_dt->add( new DateInterval( 'P1D' ) ) );
		foreach ( $period as $day ) {
			$days[] = [
				'date'  => $day->format( 'Y-m-d' ),
				'label' => $day->format( 'D d M' ),
			];
		}

		$resources = array_map(
			static function ( array $row ): array {
				return [
					'id'       => (int) $row['id'],
					'title'    => $row['title'],
					'capacity' => isset( $row['capacity'] ) ? (int) $row['capacity'] : 0,
					'type'     => $row['type'],
				];
			},
			$this->resources->all()
		);

		$start_iso = $from_dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		$end_iso   = $to_dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );

		$bookings = $this->bookings->all_between( $start_iso, $end_iso );
		$booking_map = [];
		foreach ( $bookings as $booking ) {
			$booking_map[ (int) $booking['id'] ] = $this->format_booking( $booking );
		}

		$assignments = $this->assignments->between( $start_iso, $end_iso );
		$structured_assignments = array_map(
			function( array $row ) use ( $booking_map ) {
				return $this->format_assignment( $row, $booking_map );
			},
			$assignments
		);

		return [
			'context' => [
				'days'      => $days,
				'resources' => $resources,
			],
			'assignments' => $structured_assignments,
		];
	}

	/**
	 * Format a single assignment row.
	 */
	public function format_assignment( array $row, array $booking_map = [] ): array {
		$booking = null;
		$booking_id = isset( $row['booking_id'] ) ? (int) $row['booking_id'] : 0;
		if ( $booking_id ) {
			if ( isset( $booking_map[ $booking_id ] ) ) {
				$booking = $booking_map[ $booking_id ];
			} else {
				$booking_row = $this->bookings->find( $booking_id );
				if ( $booking_row ) {
					$booking = $this->format_booking( $booking_row );
				}
			}
		}

		return [
			'id'          => isset( $row['id'] ) ? (int) $row['id'] : 0,
			'booking_id'  => $booking_id,
			'resource_id' => isset( $row['resource_id'] ) ? (int) $row['resource_id'] : 0,
			'role'        => $row['role'] ?? 'primary',
			'notes'       => $row['notes'] ?? '',
			'period'      => [
				'from' => $row['start_datetime'] ?? '',
				'to'   => $row['end_datetime'] ?? '',
			],
			'booking'     => $booking,
		];
	}

	/**
	 * Format booking details consistently.
	 */
	private function format_booking( array $booking ): array {
		return [
			'id'          => isset( $booking['id'] ) ? (int) $booking['id'] : 0,
			'order'       => isset( $booking['order_id'] ) ? (int) $booking['order_id'] : null,
			'customer_id' => isset( $booking['customer_id'] ) ? (int) $booking['customer_id'] : null,
			'color'       => self::status_color( $booking['status'] ?? 'draft' ),
			'notes'       => $booking['meta'] ?? '',
			'period'      => [
				'from' => $booking['start_datetime'] ?? '',
				'to'   => $booking['end_datetime'] ?? '',
			],
			'currency'    => $booking['currency'] ?? 'EUR',
			'total'       => isset( $booking['total'] ) ? (float) $booking['total'] : 0.0,
			'status'      => $booking['status'] ?? 'draft',
		];
	}

	/**
	 * Basic status → color mapping.
	 */
	public static function status_color( string $status ): string {
		switch ( $status ) {
			case 'confirmed':
				return '#22c55e';
			case 'cancelled':
				return '#ef4444';
			case 'pending':
				return '#f97316';
			default:
				return '#94a3b8';
		}
	}
}
