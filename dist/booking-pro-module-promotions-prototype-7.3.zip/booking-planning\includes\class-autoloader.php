<?php
/**
 * Autoloader for Planning add-on.
 *
 * @package Booking_Planning
 */

namespace Booking_Planning;

final class Autoloader {
	private static string $prefix   = 'Booking_Planning\\';
	private static string $base_dir = '';

	public static function register(): void {
		self::$base_dir = rtrim( BOOKING_PLANNING_PATH . 'includes/', '/' ) . '/';
		spl_autoload_register( [ __CLASS__, 'autoload' ] );
	}

	private static function autoload( string $class ): void {
		if ( 0 !== strpos( $class, self::$prefix ) ) {
			return;
		}

		$relative_class = substr( $class, strlen( self::$prefix ) );
		$relative_class = ltrim( $relative_class, '\\' );
		$parts          = explode( '\\', $relative_class );
		$filename       = 'class-' . strtolower( str_replace( '_', '-', array_pop( $parts ) ) ) . '.php';

		$path = '';
		if ( ! empty( $parts ) ) {
			$directories = array_map(
				static function ( $segment ) {
					return strtolower( str_replace( '_', '-', $segment ) );
				},
				$parts
			);
			$path = implode( '/', $directories ) . '/';
		}

		$file = self::$base_dir . $path . $filename;
		if ( file_exists( $file ) ) {
			require_once $file;
		}
	}
}
