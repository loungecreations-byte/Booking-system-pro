<?php
if (!defined('ABSPATH')) {
    exit;
}

class SBDP_Plugin {
  const MIN_WP_VERSION  = '5.8';
  const MIN_PHP_VERSION = '7.4';
  const MIN_WC_VERSION  = '7.0';

  private static $booted = false;
  private static $notice = '';

  public static function boot(){
    if (self::$booted) {
      return;
    }
    self::$booted = true;

    add_action('init', [__CLASS__,'init']);
    add_action('admin_notices', [__CLASS__,'maybe_render_notice']);
    add_filter('plugin_action_links_'.plugin_basename(SBDP_FILE), [__CLASS__,'register_plugin_links']);
  }

  public static function init(){
    self::load_textdomain();

    if (!self::is_environment_compatible()) {
      return;
    }

    if (class_exists('BSP_Core_Agent')) {
      \BSP_Core_Agent::instance();
    }
    SBDP_Legacy_Loader::init();
    add_filter('rest_authentication_errors',[__CLASS__,'maybe_allow_public_rest'],999);
  }

  private static function load_textdomain(){
    load_plugin_textdomain('sbdp', false, dirname(plugin_basename(SBDP_FILE)).'/languages');
  }

  private static function is_environment_compatible(){
    global $wp_version;

    if (version_compare(PHP_VERSION, self::MIN_PHP_VERSION, '<')) {
      self::$notice = sprintf(
        __('Booking Pro Module vereist minimaal PHP %s. Huidige versie: %s.','sbdp'),
        self::MIN_PHP_VERSION,
        PHP_VERSION
      );
      return false;
    }

    if (version_compare($wp_version, self::MIN_WP_VERSION, '<')) {
      self::$notice = sprintf(
        __('Booking Pro Module vereist minimaal WordPress %s. Huidige versie: %s.','sbdp'),
        self::MIN_WP_VERSION,
        $wp_version
      );
      return false;
    }

    if (!class_exists('WooCommerce')) {
      self::$notice = __('Booking Pro Module vereist dat WooCommerce actief is. Activeer WooCommerce om verder te gaan.','sbdp');
      return false;
    }

    if (defined('WC_VERSION') && version_compare(WC_VERSION, self::MIN_WC_VERSION, '<')) {
      self::$notice = sprintf(
        __('Booking Pro Module vereist minimaal WooCommerce %s. Huidige versie: %s.','sbdp'),
        self::MIN_WC_VERSION,
        WC_VERSION
      );
      return false;
    }

    self::$notice = '';
    return true;
  }

  public static function maybe_render_notice(){
    if (empty(self::$notice)) {
      return;
    }
    printf(
      '<div class="notice notice-error"><p>%s</p></div>',
      esc_html(self::$notice)
    );
  }

  public static function register_plugin_links($links){
    $links[] = sprintf(
      '<a href="%s">%s</a>',
      esc_url(admin_url('admin.php?page=sbdp_bookings')),
      esc_html__('Planner','sbdp')
    );
    $links[] = sprintf(
      '<a href="%s" target="_blank" rel="noopener">%s</a>',
      esc_url('https://owncreations.com'),
      esc_html__('Ondersteuning','sbdp')
    );
    return $links;
  }

  public static function maybe_allow_public_rest($result){
    if (empty($result) || !($result instanceof WP_Error)) {
      return $result;
    }

    $route = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
    if (strpos($route, '/wp-json/sbdp/v1/') !== false) {
      return null;
    }

    return $result;
  }
}

class SBDP_Legacy_Loader {
  private static $initialized = false;

  public static function init(){
    if (class_exists(\BSPModule\Core\Module::class)) {
      return;
    }

    if (self::$initialized) {
      return;
    }

    self::$initialized = true;

    require_once SBDP_DIR.'includes/class-cpt.php';
    if (class_exists('SBDP_CPT')) {
      SBDP_CPT::init();
    }

    require_once SBDP_DIR.'includes/class-product-type.php';
    if (class_exists('SBDP_Product_Type')) {
      SBDP_Product_Type::init();
    }

    require_once SBDP_DIR.'includes/class-product-meta.php';
    require_once SBDP_DIR.'includes/class-meta-display.php';

    require_once SBDP_DIR.'includes/class-admin-menu.php';
    if (class_exists('SBDP_Admin_Menu')) {
      SBDP_Admin_Menu::init();
    }

    require_once SBDP_DIR.'includes/class-admin-scheduler.php';
    if (class_exists('SBDP_Admin_Scheduler')) {
      SBDP_Admin_Scheduler::init();
    }

    $bookable_admin = SBDP_DIR.'includes/admin/class-bookable-meta.php';
    if (file_exists($bookable_admin)) {
      require_once $bookable_admin;
      if (class_exists('\\SBDP\\Admin\\Bookable\\SBDP_Admin_Bookable_Meta')) {
        \SBDP\Admin\Bookable\SBDP_Admin_Bookable_Meta::init();
      }
    }

    require_once SBDP_DIR.'includes/class-rest.php';
    if (class_exists('SBDP_REST')) {
      SBDP_REST::init();
    }

    require_once SBDP_DIR.'includes/class-shortcodes.php';
    if (class_exists('SBDP_Shortcodes')) {
      SBDP_Shortcodes::init();
    }

    require_once SBDP_DIR.'includes/class-enqueue.php';
    if (class_exists('SBDP_Enqueue')) {
      SBDP_Enqueue::init();
    }

    require_once SBDP_DIR.'includes/class-emails.php';
    if (class_exists('SBDP_Emails')) {
      SBDP_Emails::init();
    }

    require_once SBDP_DIR.'includes/class-resource-meta.php';
    if (class_exists('SBDP_Resource_Meta')) {
      SBDP_Resource_Meta::init();
    }

    $elementor_file = SBDP_DIR.'includes/class-elementor.php';
    if (file_exists($elementor_file)) {
      require_once $elementor_file;
      if (class_exists('SBDP_Elementor_Integration')) {
        SBDP_Elementor_Integration::init();
      }
    }
  }
}
