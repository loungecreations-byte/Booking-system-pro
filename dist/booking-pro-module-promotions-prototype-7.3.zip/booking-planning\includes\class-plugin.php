<?php
/**
 * Planning add-on bootstrap.
 *
 * @package Booking_Planning
 */

namespace Booking_Planning;

use Booking_Planning\Admin\Dashboard;
use Booking_Planning\Rest\Planning_Controller;

final class Plugin {
	/**
	 * Singleton flag.
	 */
	private static bool $bootstrapped = false;

	/**
	 * Compatibility error message.
	 */
	private static string $compat_error = '';

	/**
	 * Bootstrap hooks.
	 */
	public static function init(): void {
		if ( self::$bootstrapped ) {
			return;
		}

		self::$bootstrapped = true;

		add_action( 'plugins_loaded', [ __CLASS__, 'on_plugins_loaded' ], 20 );
		add_action( 'admin_notices', [ __CLASS__, 'render_admin_notice' ] );
	}

	/**
	 * Plugins loaded hook.
	 */
	public static function on_plugins_loaded(): void {
		if ( ! self::check_compatibility() ) {
			return;
		}

		Dashboard::register();
		Rest::register();

		add_action( 'booking_core/admin_enqueue', [ Dashboard::class, 'enqueue_assets' ] );
		add_action( 'sbdp_booking_confirmed', [ __CLASS__, 'maybe_auto_assign' ], 10, 1 );
	}

	/**
	 * Ensure booking-core is active and meets requirements.
	 */
	private static function check_compatibility(): bool {
		if ( version_compare( get_bloginfo( 'version' ), BOOKING_PLANNING_MIN_WP, '<' ) ) {
			self::$compat_error = sprintf(
				/* translators: 1: required WordPress version, 2: current version */
				__( 'Booking Planning requires WordPress %1$s or higher (running %2$s).', 'booking-planning' ),
				BOOKING_PLANNING_MIN_WP,
				get_bloginfo( 'version' )
			);

			return false;
		}

		if ( ! defined( 'BOOKING_CORE_VERSION' ) ) {
			self::$compat_error = __( 'Booking Planning requires the Booking System Pro Core plugin to be active.', 'booking-planning' );

			return false;
		}

		if ( version_compare( BOOKING_CORE_VERSION, BOOKING_PLANNING_MIN_CORE, '<' ) ) {
			self::$compat_error = sprintf(
				/* translators: 1: required core version, 2: current version */
				__( 'Booking Planning requires Booking System Pro Core version %1$s or higher (running %2$s).', 'booking-planning' ),
				BOOKING_PLANNING_MIN_CORE,
				BOOKING_CORE_VERSION
			);

			return false;
		}

		return true;
	}

	/**
	 * Surface compatibility errors in admin.
	 */
	public static function render_admin_notice(): void {
		if ( empty( self::$compat_error ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			esc_html( self::$compat_error )
		);
	}

	/**
	 * Placeholder auto assignment hook.
	 */
	public static function maybe_auto_assign( int $booking_id ): void {
		do_action( 'booking_planning/auto_assign', $booking_id );
	}
}

final class Rest {
	public static function register(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	public static function register_routes(): void {
		( new Planning_Controller() )->register_routes();
	}
}





