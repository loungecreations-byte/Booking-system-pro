<?php
/**
 * Availability REST controller.
 *
 * @package Booking_Core
 */

namespace Booking_Core\Rest;

use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

final class Availability_Controller extends Base_Controller {
	/**
	 * REST base.
	 *
	 * @var string
	 */
	protected string $rest_base = 'availability';

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'check_read_permissions' ],
				],
			],
			false
		);
	}

	/**
	 * Fetch availability placeholder.
	 */
	public function get_items( WP_REST_Request $request ) {
		$params = [
			'from' => sanitize_text_field( $request->get_param( 'from' ) ),
			'to'   => sanitize_text_field( $request->get_param( 'to' ) ),
		];

		if ( empty( $params['from'] ) || empty( $params['to'] ) ) {
			return new WP_Error( 'booking_core_missing_params', __( 'Required parameters from/to.', 'booking-core' ), [ 'status' => 400 ] );
		}

		$data = apply_filters( 'booking_core/rest/availability', [], $params );

		return new WP_REST_Response( $data, 200 );
	}
}
