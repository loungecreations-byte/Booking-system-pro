(function(){if(window?.wp?.element){console.info('BSP Sales admin UI booted');}})();
