<?php
/**
 * Resources REST controller.
 *
 * @package Booking_Core
 */

namespace Booking_Core\Rest;

use WP_REST_Request;
use WP_REST_Response;

final class Resources_Controller extends Base_Controller {
	/**
	 * REST base.
	 *
	 * @var string
	 */
	protected string $rest_base = 'resources';

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			[
				[
					'methods'             => 'GET',
					'callback'            => [ $this, 'get_items' ],
					'permission_callback' => [ $this, 'check_read_permissions' ],
				],
			],
			false
		);
	}

	/**
	 * Fetch resources (stub).
	 */
	public function get_items( WP_REST_Request $request ): WP_REST_Response { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		$data = apply_filters( 'booking_core/rest/resources', [] );

		return new WP_REST_Response( $data, 200 );
	}
}
