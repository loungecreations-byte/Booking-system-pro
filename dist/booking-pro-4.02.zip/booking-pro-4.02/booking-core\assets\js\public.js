(function(){
	if (!window.BookingCoreConfig) {
		return;
	}
	// Placeholder boot logic - add-on scripts will extend this namespace.
	window.BookingCore = window.BookingCore || {};
})();
