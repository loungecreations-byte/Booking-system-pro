<?php

/**
 * Planning REST controller.
 *
 * @package Booking_Planning
 */

namespace Booking_Planning\Rest;

use Booking_Core\Rest\Base_Controller;
use Booking_Core\Database\Repository\Bookings_Repository;
use Booking_Core\Database\Repository\Assignments_Repository;
use Booking_Planning\Services\Matrix_Builder;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;
use DateTimeImmutable;
use Exception;
use wpdb;

final class Planning_Controller extends Base_Controller {

	/**
	 * Namespace override for planning endpoints.
	 *
	 * @var string
	 */
	protected $namespace = 'sbdp-planning/v1';

	/**
	 * REST base.
	 *
	 * @var string
	 */
	protected $rest_base = 'matrix';

	/**
	 * Register routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => 'GET',
					'callback'            => array( $this, 'get_matrix' ),
					'permission_callback' => array( $this, 'check_read_permissions' ),
				),
			),
			false
		);

		register_rest_route(
			$this->namespace,
			'/assignments',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( $this, 'update_assignment' ),
					'permission_callback' => array( $this, 'check_write_permissions' ),
				),
			),
			false
		);
	}

	/**
	 * Return planning matrix payload.
	 *
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function get_matrix( $request ) {
		try {
			$timezone = wp_timezone();
			if ( empty( $from ) ) {
				$from = ( new DateTimeImmutable( 'now', $timezone ) )->format( 'Y-m-d' );
			}

			if ( empty( $to ) ) {
				$to = ( new DateTimeImmutable( $from, $timezone ) )->modify( '+6 days' )->format( 'Y-m-d' );
			}
		} catch ( Exception $e ) {
			return new WP_Error( 'booking_planning_invalid_date', __( 'Invalid date parameters.', 'booking-planning' ), array( 'status' => 400 ) );
		}

		global $wpdb;
		$builder = new Matrix_Builder( $wpdb );
		$matrix  = $builder->build( $from, $to );

		return new WP_REST_Response(
			apply_filters(
				'booking_planning/rest/matrix',
				$matrix,
				array(
					'from' => $from,
					'to'   => $to,
				)
			),
			200
		);
	}

	/**
	 * Handle drag/drop assignment update.
	 *
	 *
	 * @param WP_REST_Request $request Request.
	 */
	public function update_assignment( $request ) {
		$start         = sanitize_text_field( (string) $request->get_param( 'start' ) );
		$end           = sanitize_text_field( (string) $request->get_param( 'end' ) );
		$role          = sanitize_text_field( (string) ( $request->get_param( 'role' ) ?? 'primary' ) );
		$notes         = sanitize_textarea_field( (string) ( $request->get_param( 'notes' ) ?? '' ) );

		$booking_id    = absint( $request->get_param( 'booking_id' ) );
		$resource_id   = absint( $request->get_param( 'resource_id' ) );
		$assignment_id = absint( $request->get_param( 'assignment_id' ) );
		if ( ! $booking_id || ! $resource_id ) {
			return new WP_Error( 'booking_planning_invalid_params', __( 'Missing booking_id or resource_id.', 'booking-planning' ), array( 'status' => 400 ) );
		}

		if ( empty( $start ) || empty( $end ) ) {
			return new WP_Error( 'booking_planning_missing_period', __( 'Start- en eindtijd zijn verplicht.', 'booking-planning' ), array( 'status' => 400 ) );
		}

		global $wpdb;
		$bookings_repo    = new Bookings_Repository( $wpdb );
		$assignments_repo = new Assignments_Repository( $wpdb );
		$builder          = new Matrix_Builder( $wpdb );

		$booking = $bookings_repo->find( $booking_id );
		if ( ! $booking ) {
			return new WP_Error( 'booking_planning_unknown_booking', __( 'Booking kon niet worden gevonden.', 'booking-planning' ), array( 'status' => 404 ) );
		}

		if ( $assignment_id ) {
			$current = $assignments_repo->find( $assignment_id );
			if ( ! $current ) {
				return new WP_Error( 'booking_planning_assignment_missing', __( 'Assignment bestaat niet meer.', 'booking-planning' ), array( 'status' => 404 ) );
			}

			if ( (int) $current['booking_id'] !== $booking_id ) {
				return new WP_Error( 'booking_planning_assignment_mismatch', __( 'Assignment hoort niet bij deze boeking.', 'booking-planning' ), array( 'status' => 400 ) );
			}
		}

		$saved = $assignments_repo->save(
			array(
				'id'             => $assignment_id ?: null,
				'booking_id'     => $booking_id,
				'resource_id'    => $resource_id,
				'start_datetime' => $start,
				'end_datetime'   => $end,
				'role'           => $role,
				'notes'          => $notes,
			)
		);

		if ( ! $saved ) {
			return new WP_Error( 'booking_planning_assignment_failed', __( 'Assignment kon niet worden opgeslagen.', 'booking-planning' ), array( 'status' => 500 ) );
		}

		$normalized = $builder->format_assignment( $saved );

		do_action( 'booking_planning/rest/assignment_saved', $normalized, $request );

		return new WP_REST_Response(
			array(
				'assignment' => $normalized,
			),
			200
		);
	}
}

